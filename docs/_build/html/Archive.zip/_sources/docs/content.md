Content in Jupyter Book
=======================

There are many ways to write content in Jupyter Book. This short section
covers a few tips for how to do so.
