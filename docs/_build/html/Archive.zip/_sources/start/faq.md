# Frequently Asked Questions

This page contains the most asked questions.

### Why there are random chapters in the navigation?

Well the reason is simple. As soon as we have material ready we 
put it online. But we don't work on the chapter in linear fashion.
So you will find more chapters as time goes on. But they will
appear in what it seems random order.



