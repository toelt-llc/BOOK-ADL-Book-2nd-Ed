# Introduction

This is the online book compantion of our _Applied Deep Learning
2nd edition book_ that will be published by APRESS in 2022. Material
will continue to grow and it will complement the book itself that will
contain more theory and explanations. The material you will find 
here will be much more focused on hands-on and coding. 
